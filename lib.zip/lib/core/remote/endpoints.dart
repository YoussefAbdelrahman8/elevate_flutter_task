abstract class Endpoints{
  static const String products = "/products";
}