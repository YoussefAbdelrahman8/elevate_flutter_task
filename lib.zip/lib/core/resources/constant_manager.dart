abstract class ConstantManager{
  static const baseUrl = "https://fakestoreapi.com";
}