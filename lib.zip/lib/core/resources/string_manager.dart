abstract class StringManager{

}