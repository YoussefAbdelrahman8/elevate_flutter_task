abstract class Routes{
  static const String productsCatalogScreenRoute = "/products";
}