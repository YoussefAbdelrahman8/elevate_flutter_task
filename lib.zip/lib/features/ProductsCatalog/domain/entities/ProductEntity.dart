class ProductEntity {
  ProductEntity({
    this.id,
    this.title,
    this.price,
    this.image,
    this.rating,
  });

  num? id;
  String? title;
  num? price;
  String? image;
  num? rating;
}
